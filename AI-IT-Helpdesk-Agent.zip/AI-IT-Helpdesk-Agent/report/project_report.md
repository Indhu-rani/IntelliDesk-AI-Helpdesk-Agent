# AI IT Helpdesk Agent: An Intelligent Troubleshooting Assistant

### Internship / Academic Project Report

---

## 1. Cover Page

**Project Title:** AI IT Helpdesk Agent: An Intelligent Troubleshooting Assistant
**Category:** Agentic AI Internship Project (Agent + RAG + Tools)
**Submitted By:** [Your Full Name]
**Roll Number / Student ID:** [Your Roll Number]
**Course / Program:** [Your Course, e.g. B.Tech Computer Science]
**Institution:** [Your College / University Name]
**Internship Organization / Guide:** [Organization Name, if applicable]
**Submitted To:** [Faculty / Supervisor Name]
**Academic Year:** [e.g. 2025–2026]
**Date of Submission:** [Insert Date]

---

## 2. Certificate / Declaration

*(Replace with your institution's official certificate format if provided.)*

This is to certify that the project titled **"AI IT Helpdesk Agent: An
Intelligent Troubleshooting Assistant"** is a bona fide work carried out by
**[Your Name]**, [Roll Number], in partial fulfillment of the requirements
for [Degree/Course Name], during the academic year [Year], under the
guidance of [Guide/Supervisor Name].

**Student Declaration:** I hereby declare that this project report is my
own work, carried out under the supervision mentioned above, and has not
been submitted elsewhere for any other degree or diploma.

Signature of Student: ______________________
Signature of Guide/Supervisor: ______________________
Signature of Head of Department: ______________________

---

## 3. Acknowledgement

I would like to express my sincere gratitude to [Guide/Supervisor Name]
for their valuable guidance and support throughout this project. I also
thank [Institution/Department Name] for providing the opportunity and
resources to undertake this Agentic AI internship project. Finally, I
thank my family and friends for their continuous encouragement.

*(Personalize this section with actual names before submission.)*

---

## 4. Abstract

Modern IT support desks handle a high volume of repetitive, low-complexity
requests such as Wi-Fi connectivity problems, forgotten passwords, printer
malfunctions, and slow computer performance. This project presents the
design and implementation of an **AI IT Helpdesk Agent**, a prototype
agentic AI system that automates first-line IT troubleshooting support.

The system combines four core techniques: (1) **Agentic AI**, where a
central controller reasons through a sequence of steps — issue detection,
knowledge retrieval, decision-making, and tool execution — rather than
returning a single static response; (2) **Retrieval-Augmented Generation
(RAG)**, implemented using TF-IDF vectorization and cosine similarity to
retrieve the most relevant troubleshooting guidance from a local knowledge
base, minimizing the risk of the system inventing incorrect information;
(3) **Tool Calling**, where the agent invokes simulated tools — a Network
Status checker, a System Status checker, and a Support Ticket generator —
based on the nature of the reported issue; and (4) **Conversation Memory**,
which allows the agent to track the ongoing conversation within a session
and respond appropriately to follow-up messages, such as recognizing when
a previously suggested fix did not work.

The system is implemented entirely in Python using the scikit-learn
library for the RAG component and Streamlit for the user interface,
without requiring any external, paid Large Language Model (LLM) API. This
report documents the problem context, system design, implementation
details, testing approach, and results, along with the project's
limitations and directions for future enhancement. The application
described here is a functional prototype intended for academic
demonstration and does not connect to any real company IT infrastructure.

---

## 5. Table of Contents

1. Cover Page
2. Certificate / Declaration
3. Acknowledgement
4. Abstract
5. Table of Contents
6. Introduction
7. Problem Statement
8. Existing System
9. Proposed System
10. Objectives
11. Scope
12. Technologies Used
13. System Requirements
14. System Architecture
15. Agentic AI Workflow
16. RAG Methodology
17. Knowledge Base
18. Tool Calling
19. Conversation Memory
20. System Design
21. Implementation
22. User Interface
23. Testing
24. Results and Outputs
25. Advantages
26. Limitations
27. Future Enhancements
28. Conclusion
29. References

---

## 6. Introduction

Artificial Intelligence has increasingly been applied to customer and
technical support scenarios to reduce response times and operational
costs. A significant subset of IT helpdesk tickets involve common,
well-documented issues — connectivity problems, login failures, printer
malfunctions, sluggish system performance, failed software installations,
and generic system errors — for which standard troubleshooting procedures
already exist.

This project explores **Agentic AI**: AI systems designed not merely to
answer a question, but to reason through a workflow — understanding a
request, retrieving relevant knowledge, deciding on next actions, invoking
tools where appropriate, and maintaining context across a conversation.
The AI IT Helpdesk Agent developed in this project is a practical,
scoped-down demonstration of these principles, built to be simple enough
for a student to fully understand, implement, test, and defend in a viva,
while still faithfully representing the core ideas found in production
agentic systems.

## 7. Problem Statement

IT support teams are frequently occupied by a high proportion of routine,
repetitive requests. Manually addressing each of these consumes time that
could otherwise be spent on complex, high-priority issues. There is a need
for a lightweight, automated first line of support that can:

- Understand a user's plain-language description of a technical problem.
- Provide accurate, relevant troubleshooting guidance without inventing information.
- Perform basic diagnostic checks to assist in the troubleshooting process.
- Escalate to human support when the automated guidance is insufficient or has already failed.
- Do all of this without requiring expensive infrastructure or external paid AI services.

## 8. Existing System

Most existing IT helpdesk solutions fall into one of the following
categories:

- **Static FAQ/knowledge-base portals:** Users must manually search for
  their issue; there is no interactive guidance or conversational memory.
- **Rule-based chatbots:** Often rigid decision trees that cannot easily
  adapt to varied phrasing of the same issue and do not retrieve
  information dynamically.
- **Full LLM-based assistants:** Powerful and flexible, but typically
  depend on external paid APIs, raising cost, data-privacy, and
  infrastructure-dependency concerns — impractical for a student project
  with the constraint of "no external API key required."

None of these fully combines retrieval-grounded answers, tool-based
diagnostics, and conversational memory in a lightweight, locally-runnable
package suitable for an academic demonstration.

## 9. Proposed System

The proposed system, the **AI IT Helpdesk Agent**, addresses the gaps
above by combining:

- A rule-based **issue detection** step to classify the type of problem.
- A **RAG retrieval** step (TF-IDF + cosine similarity) grounding all
  troubleshooting guidance in a curated knowledge base file, so the system
  never fabricates instructions.
- A **decision-making** step where the agent determines whether a
  supporting tool should be invoked.
- Three **simulated tools** (Network Status, System Status, Support
  Ticket) that mimic real diagnostic/ticketing actions without requiring
  access to real infrastructure.
- **Conversation memory** so that the agent can recognize follow-up
  messages and adjust its response (e.g., escalate rather than repeat
  advice).
- A **Streamlit-based chat interface** for an accessible, demonstrable
  user experience.

## 10. Objectives

1. Design and implement an agentic workflow that reasons through issue
   detection, retrieval, decision-making, and tool execution.
2. Implement a RAG pipeline using classical, transparent NLP techniques
   (TF-IDF and cosine similarity) rather than a black-box model.
3. Implement at least three simulated tools that the agent can invoke
   based on context.
4. Implement conversation memory that materially affects the agent's
   responses to follow-up messages.
5. Build a usable, presentable Streamlit user interface.
6. Ensure the entire system runs locally without any external API key.
7. Document, test, and prepare the project for both practical
   demonstration and academic viva defense.

## 11. Scope

**In scope:**
- Text-based troubleshooting assistance for six issue categories: Wi-Fi/
  internet, login/password, printer, computer performance, software
  installation, and system errors, plus an escalation pathway.
- Simulated diagnostic and ticketing tools.
- Single-user, single-session conversation memory.
- A Streamlit web-based chat interface for local use.

**Out of scope:**
- Real integration with any organization's actual network, systems, or
  ticketing software.
- Multi-user authentication, role-based access, or persistent multi-session
  storage.
- Deep semantic/embedding-based search or a locally hosted large language
  model.
- Deployment to cloud infrastructure, containers, or orchestration systems.

## 12. Technologies Used

| Layer | Technology | Purpose |
|---|---|---|
| Programming Language | Python 3.10+ | Core implementation language |
| UI Framework | Streamlit | Web-based chat interface |
| RAG / NLP | scikit-learn (`TfidfVectorizer`, `cosine_similarity`) | Knowledge base retrieval |
| Data Storage | Plain text file (`troubleshooting.txt`) | Knowledge base source |
| Memory | Native Python data structures | In-session conversation history |
| Tools | Custom Python functions | Simulated network/system/ticket actions |
| Version Control | Git / GitHub | Source code hosting and submission |

No external LLM API, database server, authentication system, or container
platform is used, in line with the project's scope constraints.

## 13. System Requirements

**Hardware Requirements (minimum):**
- Any modern PC/laptop with at least 4 GB RAM.
- No GPU required.

**Software Requirements:**
- Python 3.10 or later.
- pip (Python package manager).
- A modern web browser (for viewing the Streamlit interface).
- Git (optional, for version control and GitHub submission).

**Python Package Requirements** (see `requirements.txt`):
- `streamlit`
- `scikit-learn`

## 14. System Architecture

The system follows a layered architecture:

1. **Presentation Layer (`app.py`):** Streamlit chat interface — captures
   user input, displays the conversation, and offers a "Clear Chat" reset.
2. **Agent / Controller Layer (`agent.py`):** The `ITHelpdeskAgent` class,
   which coordinates issue detection, retrieval, decision-making, tool
   execution, and memory updates.
3. **Retrieval Layer (`rag.py`):** The `SimpleRAG` class, which loads and
   indexes the knowledge base and performs TF-IDF + cosine similarity
   retrieval.
4. **Tool Layer (`tools.py`):** Independent, stateless functions
   implementing the three simulated tools.
5. **Memory Layer (`memory.py`):** The `ConversationMemory` class, storing
   the session's message history.
6. **Data Layer (`knowledge_base/troubleshooting.txt`):** The static,
   curated knowledge source used by the retrieval layer.

```
        ┌───────────────────────┐
        │   Streamlit UI Layer   │   app.py
        └───────────┬───────────┘
                     │
        ┌───────────▼───────────┐
        │   Agent Controller     │   agent.py (ITHelpdeskAgent)
        └───┬────────────────┬──┘
            │                │
   ┌────────▼──────┐   ┌─────▼─────────┐
   │  RAG Retrieval │   │  Tool Layer    │  rag.py / tools.py
   │  (TF-IDF +     │   │  (Network /    │
   │   Cosine Sim.) │   │  System /      │
   └────────┬──────┘   │  Ticket)       │
            │           └────────────────┘
   ┌────────▼──────────┐
   │ Knowledge Base File │
   └────────────────────┘

            ▲
            │
   ┌────────┴────────────┐
   │ Conversation Memory   │  memory.py
   └──────────────────────┘
```

## 15. Agentic AI Workflow

The agent processes every user query through the following pipeline
(implemented in `ITHelpdeskAgent.handle_query()`):

1. **Input validation** — empty or whitespace-only input is rejected with a friendly prompt.
2. **Issue Detection** — keyword-based classification into one of seven categories (network, login, printer, performance, software_install, system_error, escalation) or "unknown."
3. **RAG Retrieval** — the query is compared against the knowledge base using TF-IDF and cosine similarity; the best match is returned only if it clears a minimum confidence threshold.
4. **Decision Making** — the agent examines the detected category and whether the current message is a follow-up to a previous message on the same topic (using conversation memory) to decide whether a tool should be used.
5. **Tool Selection & Execution** — the appropriate tool (Network Status, System Status, or Support Ticket) is executed, or no tool is used if not applicable.
6. **Memory Update** — both the user's message (with its detected category) and the agent's generated response are stored in `ConversationMemory`.
7. **Final Response Construction** — the retrieved knowledge and any tool output are combined into a single, readable response shown to the user.

This pipeline embodies the defining trait of agentic systems: the flow of
control and the final action taken are **determined dynamically by the
agent's own reasoning about the input and context**, not hard-coded per
individual query.

## 16. RAG Methodology

Retrieval-Augmented Generation (RAG) is used here to ensure that all
troubleshooting guidance shown to the user comes from a trusted,
human-authored source rather than being generated freely (and potentially
incorrectly) by a model. The methodology:

1. **Chunking:** The knowledge base file is split into sections, one per
   `CATEGORY:` heading (e.g., "Wi-Fi and Internet Issues," "Printer
   Issues").
2. **Vectorization:** Each chunk, and later each user query, is converted
   into a TF-IDF (Term Frequency–Inverse Document Frequency) vector using
   scikit-learn's `TfidfVectorizer` with English stop-word removal.
3. **Similarity Scoring:** Cosine similarity is computed between the
   query vector and every chunk vector, producing a similarity score
   between 0 and 1 for each chunk.
4. **Ranking & Thresholding:** Chunks are ranked by score; the top match
   is returned only if its score is at least `0.08` (`SIMILARITY_THRESHOLD`
   in `rag.py`). Queries that do not clear this threshold are treated as
   "not covered" so the system can honestly say it found no confident
   match, instead of returning a poor or misleading match.

This approach is intentionally simple and interpretable — an important
property for a student project, since every retrieval decision can be
traced back to a specific similarity score and knowledge base section.

## 17. Knowledge Base

The knowledge base (`knowledge_base/troubleshooting.txt`) is a structured
plain-text file covering seven categories:

1. Wi-Fi and Internet Issues
2. Password and Login Issues
3. Printer Issues
4. Computer Performance Issues
5. Software Installation Issues
6. System Errors
7. IT Support Escalation

Each category contains a short problem description followed by a
numbered sequence of practical, safe troubleshooting steps, written to
reflect realistic (but generic, non-company-specific) IT support
guidance. The file uses a simple `CATEGORY:` marker convention so it can
be parsed and chunked programmatically by `rag.py` without needing a
database or external document store.

## 18. Tool Calling

Three tools are defined in `tools.py`, each implemented as a standalone
Python function returning a dictionary of results:

1. **Network Status Tool (`check_network_status`)** — Simulates a check
   of Wi-Fi connectivity, internet availability, and signal strength,
   returning a randomly-varied but realistic result set for
   demonstration purposes.
2. **System Status Tool (`check_system_status`)** — Simulates checking
   CPU usage, memory usage, and free storage space, and derives a simple
   status message (e.g., flagging heavy load or low storage).
3. **Support Ticket Tool (`create_support_ticket`)** — Simulates creating
   an IT support ticket, generating a unique, timestamp-based ticket ID
   in the format `IT-YYYYMMDDHHMMSS`, along with the issue description
   and a status of "Open."

**All three tools are explicitly and clearly simulated.** They do not
connect to any real network hardware, operating system APIs, or
ticketing/helpdesk software. This is a deliberate scope decision for this
academic prototype and is documented in the README, the Testing
document, and this report to avoid any misrepresentation of the system's
real-world capabilities.

The agent's decision of *which* tool to call (if any) is made in
`ITHelpdeskAgent.decide_tool()`, based on the detected issue category and
whether the current message appears to be a follow-up indicating a
previous fix did not work.

## 19. Conversation Memory

`memory.py` defines `ConversationMemory`, a lightweight in-session store
that records every user and agent message along with a timestamp and
(for user messages) the detected issue category. It exposes:

- `add_message(role, message, category)` — records a new turn.
- `get_history()` — returns the full conversation so far.
- `get_recent_messages(n)` — returns the last *n* turns.
- `get_last_user_category()` — finds the most recently discussed issue
  category, used by the agent to detect follow-up messages.
- `clear()` — resets the conversation (used by the "Clear Chat" button).

This memory is what allows the agent to distinguish a **new** issue from
a **follow-up** on an existing one — for example, recognizing "I already
restarted the router but it still doesn't work" as a continuation of an
earlier Wi-Fi question, and responding by escalating to a support ticket
rather than repeating the same first-step advice.

The memory is intentionally scoped to a single Streamlit session (it
resets when the app restarts or a new session starts) — this is
sufficient for the project's demonstration purposes and avoids the added
complexity of persistent, multi-session storage.

## 20. System Design

**Modular design principle:** each Python file has a single, clear
responsibility (retrieval, tools, memory, agent orchestration, or UI),
which keeps the codebase easy to understand, test, and extend — an
important quality for a student project meant to be explained in a viva.

**Data flow:**
`app.py` → `ITHelpdeskAgent.handle_query(query)` → (`SimpleRAG.retrieve`,
`decide_tool`, tool function, `ConversationMemory.add_message`) →
structured result dictionary → rendered by `app.py`.

**Error-handling design:** Each layer fails gracefully — `SimpleRAG`
raises a descriptive `KnowledgeBaseError` if the knowledge base is
missing or empty rather than crashing on import; `ITHelpdeskAgent` catches
this and continues operating in a degraded mode (tools still work); tool
execution and retrieval calls are wrapped in `try/except` blocks; and
`app.py` wraps the whole query-handling call in a `try/except` so that an
unexpected error is shown to the user as a friendly message rather than
crashing the Streamlit app.

## 21. Implementation

The system is implemented across five Python modules and one data file:

- **`rag.py`** — `SimpleRAG` class: knowledge base loading, chunking,
  TF-IDF vectorization, and cosine-similarity retrieval.
- **`tools.py`** — three simulated tool functions:
  `check_network_status()`, `check_system_status()`,
  `create_support_ticket()`.
- **`memory.py`** — `ConversationMemory` class for in-session chat
  history.
- **`agent.py`** — `ITHelpdeskAgent` class: issue detection
  (`detect_category`), tool decision logic (`decide_tool`), the main
  orchestration method (`handle_query`), and response construction
  (`_build_response`).
- **`app.py`** — Streamlit UI: session-state management, sidebar project
  information, chat rendering, and input handling.
- **`knowledge_base/troubleshooting.txt`** — the structured knowledge
  source described in Section 17.

Issue detection uses straightforward keyword lists per category (see
`CATEGORY_KEYWORDS` in `agent.py`). This was a deliberate design choice
in favor of transparency and simplicity, as required by the project scope,
over a more complex machine-learning text classifier.

## 22. User Interface

The user interface is built with Streamlit and consists of:

- A **title and description** explaining the project at the top of the page.
- An **informational banner** clarifying that tools are simulated.
- A **chat interface** using `st.chat_message` and `st.chat_input`,
  showing the running conversation between the user and the agent.
- A **sidebar** listing the project name, technologies used, knowledge
  base coverage, and available tools, plus a **"Clear Chat"** button to
  reset the session.

The interface is intentionally kept simple and uncluttered, prioritizing
clarity for demonstration and viva purposes over advanced styling.

[INSERT SCREENSHOT: Application Home Page]

## 23. Testing

Testing was carried out at two levels:

1. **Module-level testing:** `rag.py`, `tools.py`, `memory.py`, and
   `agent.py` each include a `__main__` block that exercises their core
   functionality when run directly (e.g., `python3 agent.py`), which was
   used to verify correct behavior during development.
2. **Scenario-based testing:** The seven required test cases (Wi-Fi issue,
   printer issue, performance issue, login issue, explicit escalation,
   follow-up/context-aware escalation, and an out-of-scope/unknown issue)
   were each run through `ITHelpdeskAgent.handle_query()` and the detected
   category, selected tool, and response text were verified against the
   expected behavior.

All Python files were also checked for syntax correctness using
`python3 -m py_compile`. Full details, including exact commands and
observed outputs, are documented in `TESTING.md`. Per that document, the
graphical Streamlit interface itself should be manually click-tested by
the reader in their own environment, since the module-level logic behind
it has already been verified directly.

## 24. Results and Outputs

The AI IT Helpdesk Agent successfully:

- Classifies incoming queries into the correct issue category using
  keyword-based detection.
- Retrieves the correct, relevant knowledge base section for each tested
  query, with the retrieval step correctly declining to answer when no
  section is a strong match (as in the "unknown issue" test case).
- Selects and executes the appropriate simulated tool based on the issue
  category and conversation context.
- Demonstrates context-awareness by escalating to a support ticket when a
  user indicates a previously suggested fix did not resolve their issue.
- Presents all of this through a working Streamlit chat interface with a
  sidebar summarizing the project.

[INSERT SCREENSHOT: Wi-Fi Troubleshooting]
[INSERT SCREENSHOT: Printer Troubleshooting]
[INSERT SCREENSHOT: System Status Tool]
[INSERT SCREENSHOT: Support Ticket]
[INSERT SCREENSHOT: Conversation Memory]

*(No accuracy percentages, benchmark datasets, or user-adoption statistics
are reported, as none were collected or are appropriate to fabricate for
this prototype.)*

## 25. Advantages

- Runs entirely locally with no external API key or ongoing service cost.
- Transparent and explainable: every retrieval decision is traceable to a
  specific similarity score and knowledge base section, and every tool
  call is traceable to a specific rule in the agent's decision logic.
- Modular codebase that is easy for a student to understand, extend, and
  defend in a viva.
- Demonstrates all four required agentic AI concepts (agent, RAG, tools,
  memory) within a manageable scope.
- Graceful error handling avoids crashes from missing files, empty input,
  or unexpected exceptions.

## 26. Limitations

- The knowledge base is small and static; it cannot address issues
  outside its seven covered categories.
- Issue detection relies on keyword matching, which can miss unusually
  phrased queries or misclassify ambiguous ones.
- All three tools are simulated and do not interact with any real
  network, system, or ticketing infrastructure.
- Conversation memory is limited to the current session and is lost when
  the application restarts.
- The system is a single-user prototype without authentication or
  multi-user support.
- No real LLM is used, so responses are limited to combinations of
  retrieved knowledge-base text and templated tool output, rather than
  fully free-form natural language generation.

## 27. Future Enhancements

- Expand the knowledge base to cover more issue types and more detailed,
  branching troubleshooting steps.
- Replace keyword-based detection with a lightweight trained classifier
  or embedding-based semantic search for more robust issue recognition.
- Add persistent storage (e.g., SQLite) for conversation history and
  generated tickets across sessions.
- Integrate real, permissioned APIs for actual network/system diagnostics
  in a controlled organizational deployment.
- Add authentication and per-user session management for multi-user use.
- Optionally integrate a real LLM (with appropriate safeguards) for more
  natural, flexible conversational responses layered on top of the
  existing RAG grounding.

## 28. Conclusion

The AI IT Helpdesk Agent successfully demonstrates the core principles of
agentic AI — reasoning-driven control flow, retrieval-grounded knowledge
use, tool invocation, and conversational memory — within a scope
appropriate for a college-level internship project. By deliberately
avoiding external LLM APIs, complex frameworks, and production
infrastructure, the project remains simple, transparent, and fully
reproducible, while still faithfully representing how modern agentic AI
systems are structured. The resulting prototype is suitable for
demonstration, GitHub submission, and viva defense, and provides a solid
foundation for further extension into a more capable system.

## 29. References

1. Scikit-learn documentation — TF-IDF Vectorizer:
   https://scikit-learn.org/stable/modules/generated/sklearn.feature_extraction.text.TfidfVectorizer.html
2. Scikit-learn documentation — Cosine Similarity:
   https://scikit-learn.org/stable/modules/generated/sklearn.metrics.pairwise.cosine_similarity.html
3. Streamlit documentation: https://docs.streamlit.io/
4. Lewis, P. et al. (2020). "Retrieval-Augmented Generation for
   Knowledge-Intensive NLP Tasks." *NeurIPS 2020.*
5. Python 3 official documentation: https://docs.python.org/3/

*(Add any additional institution-specific references, textbooks, or
internship guidance materials you were provided.)*
